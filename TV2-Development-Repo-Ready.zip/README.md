# TV2 Development

Development repository for the List Number TV2 resolver and Flutter testbed.

## Backend
The public resolver API is in `backend/`. It supports fixture mode and PostgreSQL mode.

Render deployment configuration is in `render.yaml`.

## Security
Do not commit `.env` files, database passwords, connection strings, API keys, CDD records, consent records, or private communications routing data.
